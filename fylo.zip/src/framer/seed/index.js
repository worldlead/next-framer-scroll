'use client'
import Component from './seed.js'; export default Component