'use client'
import Component from './composition.js'; export default Component