'use client'
import Component from './radio.js'; export default Component