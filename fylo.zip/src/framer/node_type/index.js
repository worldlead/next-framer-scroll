'use client'
import Component from './node_type.js'; export default Component