'use client'
import Component from './node.js'; export default Component