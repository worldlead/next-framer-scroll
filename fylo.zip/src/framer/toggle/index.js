'use client'
import Component from './toggle.js'; export default Component