"use client";
import Component from "./fylo.js";
export default Component;
