export default function PageTransition() {
  return (
    <>
      <div className="transition-overlay-wrapper"></div>
    </>
  );
}
